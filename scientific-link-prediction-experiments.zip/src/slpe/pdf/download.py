"""Download OA PDFs from metadata-provided URLs, with limits and validation.

Respects HTTP status codes (no retry on 403/404; backoff on 429/5xx), caps bytes
per file, and applies a per-host politeness delay. Never circumvents paywalls,
authentication or technical blocks. Each attempt returns a structured record with
status, size, SHA-256 and a failure reason, so the collection funnel is auditable.
"""

from __future__ import annotations

import hashlib
import logging
import time
from dataclasses import asdict, dataclass, field
from urllib.parse import urlparse

import httpx

from slpe.config import PdfConfig
from slpe.pdf.locations import PdfCandidate
from slpe.pdf.validate import PdfValidation, validate_pdf_bytes

logger = logging.getLogger("slpe.pdf")

_NO_RETRY_STATUS = {401, 403, 404, 410}
_RETRY_STATUS = {429, 500, 502, 503, 504}


@dataclass
class DownloadAttempt:
    url: str
    source: str
    ok: bool
    http_status: int | None
    n_bytes: int
    sha256: str | None
    failure_reason: str | None
    validation: dict | None  # PdfValidation as dict when a body was fetched


@dataclass
class AcquisitionResult:
    work_id: str
    acquired: bool
    pdf_path: str | None
    sha256: str | None
    license: str | None
    version: str | None
    n_pages: int
    n_text_chars: int
    attempts: list[DownloadAttempt] = field(default_factory=list)
    failure_reason: str | None = None


@dataclass
class PdfDownloader:
    config: PdfConfig
    contact: str | None = None
    _client: httpx.Client | None = None
    _last_host_hit: dict[str, float] = field(default_factory=dict)
    total_bytes: int = 0

    @classmethod
    def create(cls, config: PdfConfig, contact: str | None = None) -> PdfDownloader:
        ua = "scientific-link-prediction-experiments/0.1 (research)"
        if contact:
            ua += f" mailto:{contact}"
        client = httpx.Client(timeout=config.timeout_seconds, follow_redirects=True,
                              headers={"User-Agent": ua, "Accept": "application/pdf,*/*"})
        return cls(config=config, contact=contact, _client=client)

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def _politeness(self, url: str) -> None:
        host = urlparse(url).netloc
        last = self._last_host_hit.get(host)
        if last is not None:
            wait = self.config.per_host_delay_seconds - (time.monotonic() - last)
            if wait > 0:
                time.sleep(wait)
        self._last_host_hit[host] = time.monotonic()

    def _download_bytes(self, url: str) -> tuple[bytes | None, int | None, str | None]:
        """Stream a URL into bytes with a size cap. Returns (data, status, reason)."""
        assert self._client is not None
        backoff = 1.0
        for attempt in range(1, self.config.max_retries + 2):
            self._politeness(url)
            try:
                with self._client.stream("GET", url) as resp:
                    status = resp.status_code
                    if status in _NO_RETRY_STATUS:
                        return None, status, f"http_{status}"
                    if status in _RETRY_STATUS:
                        if attempt <= self.config.max_retries:
                            time.sleep(backoff)
                            backoff = min(backoff * 2, 30.0)
                            continue
                        return None, status, f"http_{status}"
                    if status != 200:
                        return None, status, f"http_{status}"
                    chunks = bytearray()
                    for chunk in resp.iter_bytes():
                        chunks.extend(chunk)
                        if len(chunks) > self.config.max_bytes_per_file:
                            return None, status, "exceeds_max_bytes"
                    return bytes(chunks), status, None
            except httpx.RequestError as exc:
                if attempt <= self.config.max_retries:
                    time.sleep(backoff)
                    backoff = min(backoff * 2, 30.0)
                    continue
                return None, None, f"request_error:{type(exc).__name__}"
        return None, None, "exhausted"

    def acquire(self, work_id: str, candidates: list[PdfCandidate]) -> AcquisitionResult:
        """Try candidates in order; return the first that downloads AND validates."""
        result = AcquisitionResult(
            work_id=work_id, acquired=False, pdf_path=None, sha256=None,
            license=None, version=None, n_pages=0, n_text_chars=0,
        )
        if self.config.max_total_bytes is not None and self.total_bytes >= self.config.max_total_bytes:
            result.failure_reason = "byte_budget_exhausted"
            return result

        for cand in candidates:
            data, status, reason = self._download_bytes(cand.url)
            if data is None:
                result.attempts.append(DownloadAttempt(
                    cand.url, cand.source, False, status, 0, None, reason, None))
                continue
            self.total_bytes += len(data)
            val: PdfValidation = validate_pdf_bytes(data, min_text_chars=self.config.min_text_chars)
            sha = hashlib.sha256(data).hexdigest()
            attempt = DownloadAttempt(
                cand.url, cand.source, val.is_valid, status, len(data), sha,
                None if val.is_valid else val.reason, asdict(val))
            result.attempts.append(attempt)
            if val.is_valid:
                self.config.dir.mkdir(parents=True, exist_ok=True)
                path = self.config.dir / f"{work_id}.pdf"
                path.write_bytes(data)
                result.acquired = True
                result.pdf_path = str(path)
                result.sha256 = sha
                result.license = cand.license
                result.version = cand.version
                result.n_pages = val.n_pages
                result.n_text_chars = val.n_text_chars
                return result
        if not result.failure_reason:
            result.failure_reason = "no_valid_candidate" if candidates else "no_pdf_url"
        return result
